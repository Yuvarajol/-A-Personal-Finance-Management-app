import './numbro';
import initializeStore from 'store';

export const { store, persistor, runSaga } = initializeStore();
