import TransactionDetailsScreen from './container';

export default TransactionDetailsScreen;
