import TransactionsScreen from './container';

export default TransactionsScreen;
