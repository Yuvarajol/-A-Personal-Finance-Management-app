import SettingsScreen from './container';

export default SettingsScreen;
