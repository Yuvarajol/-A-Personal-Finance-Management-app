import InsightsScreen from './container';

export default InsightsScreen;
