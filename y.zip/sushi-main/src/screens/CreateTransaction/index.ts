import CreateTransactionScreen from './container';

export default CreateTransactionScreen;
