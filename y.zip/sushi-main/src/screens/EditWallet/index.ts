import EditWalletScreen from './container';

export default EditWalletScreen;
