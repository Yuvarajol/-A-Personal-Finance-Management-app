import WalletDetailsScreen from './container';

export default WalletDetailsScreen;
