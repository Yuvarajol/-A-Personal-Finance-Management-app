import EditTransactionScreen from './container';

export default EditTransactionScreen;
