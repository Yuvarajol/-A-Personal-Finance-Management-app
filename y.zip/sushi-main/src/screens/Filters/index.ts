import FiltersScreen from './view';

export default FiltersScreen;
