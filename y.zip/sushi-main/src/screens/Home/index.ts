import HomeScreen from './container';

export default HomeScreen;
