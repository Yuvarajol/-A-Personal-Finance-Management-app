import CreateWalletScreen from './container';

export default CreateWalletScreen;
